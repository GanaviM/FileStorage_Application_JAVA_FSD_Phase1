#!/bin/bash
java -cp target/virtualkey-1.0-SNAPSHOT.jar org.example.virtualkey.VirtualKeyApplication
